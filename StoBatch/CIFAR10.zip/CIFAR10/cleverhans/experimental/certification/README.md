Placeholder for certification code.
